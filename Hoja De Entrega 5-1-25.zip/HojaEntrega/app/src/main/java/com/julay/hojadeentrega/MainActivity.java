package com.julay.hojadeentrega;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    EditText centavos,dolares,cincoDolares,diezDolares,veinteDolares,cincuentaDolares,cienDolares,retiros;
    TextView txtCentavos,txtDolar,txtcincoDolares,txtdiezDolares,txtveinteDolares,txtcincuentaDolares,txtcienDolares,txtTotal,txtTotalCinta,txtJulay;
    Float centavo = 0f;
    Float dolar= 0f;
    Float cinco = 0f;
    Float diez= 0f;
    Float veinte= 0f;
    Float cincuenta = 0f;
    Float cien = 0f;
    Float retiro= 0f;
    Float sumaT=0f;
    Float sumaTF=0f;
    Button btnCalcular,btnBorrar,btnCalc,ib1;
    int clicJulay=0;//variable global que contara las veces que se presiona el texto by julay , decorativo
    int clicCalcular=0;
    private View.OnClickListener listener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        adjustFontScale(getResources().getConfiguration());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_home);


        centavos=(EditText)findViewById(R.id.etex01);
        dolares=(EditText)findViewById(R.id.etex1);
        cincoDolares=(EditText)findViewById(R.id.etex5);
        diezDolares=(EditText)findViewById(R.id.etex10);
        veinteDolares=(EditText)findViewById(R.id.etex20);
        cincuentaDolares=(EditText)findViewById(R.id.etex50);
        cienDolares=(EditText)findViewById(R.id.etex100);
        retiros=(EditText)findViewById(R.id.etexRetiros);

        txtCentavos=  (TextView)findViewById(R.id.txtRCentavos);
        txtDolar=(TextView)findViewById(R.id.txtRDolar);
        txtcincoDolares=(TextView)findViewById(R.id.txtRCinco);
        txtdiezDolares=(TextView)findViewById(R.id.txtRDiez);
        txtveinteDolares=(TextView)findViewById(R.id.txtRVeinte);
        txtcincuentaDolares=(TextView)findViewById(R.id.txtRCincuenta);
        txtcienDolares=(TextView)findViewById(R.id.txtRCien);
        txtTotal=(TextView)findViewById(R.id.txtTotales);
        txtTotalCinta=(TextView)findViewById(R.id.txtTotalesCinta);
        txtJulay=(TextView)findViewById(R.id.txtJulay);

        btnCalcular=(Button) findViewById(R.id.btnCalcular);
        btnBorrar=(Button)findViewById(R.id.btnBorrar);
        btnCalc=(Button)findViewById(R.id.btnCalc);
        ib1=(Button)findViewById(R.id.ib1);

        DecimalFormat f=new DecimalFormat("###,##0.00");



        ib1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                  try {
                      if (dolares.getText().toString().isEmpty()){
                          dolares.setText("0");
                      }
                      if(!dolares.getText().toString().isEmpty()){
                          String valor= dolares.getText().toString();
                          int vA= Integer.parseInt(valor);
                          vA++;

                          dolares.setText(String.valueOf(vA));
                      }

                  }catch (NumberFormatException e)
                  {
                      dolares.setText("0");
                  }


            }
        });

        //OPERACION DEL BOTON CALCULAR
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clicCalcular++;
                validacion();
                Operando();

                if(clicCalcular!=1) {
                    Toast.makeText(MainActivity.this, "👻", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this, "Exito 😎", Toast.LENGTH_SHORT).show();
                }


            }
        });


        btnCalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Intent intent=new Intent(MainActivity.this,Calculadora.class);
                //startActivity(intent);



               abrirCalc(v);
                //Toast.makeText(MainActivity.this, "Perdón Arreglaré esto! 😥", Toast.LENGTH_SHORT).show();
            }
        });

        //OPEERACION DEL BOTON BORRAR
        btnBorrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Borrar();
                clicCalcular =0;
                clicJulay=0;
            }
        });

       txtJulay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicJulay++;

                switch (clicJulay){
                    case 1: Toast.makeText(MainActivity.this, "Hoja de entrega Version 1.1", Toast.LENGTH_SHORT).show();
                    break;
                    case 2: Toast.makeText(MainActivity.this, "software de código abierto y libre", Toast.LENGTH_SHORT).show();
                    break;
                    case 3: Toast.makeText(MainActivity.this, "Desarrollado por Julay 😎", Toast.LENGTH_SHORT).show();
                    break;
                    case 4: clicJulay=0;
                        Toast.makeText(MainActivity.this, "Chale! 👀", Toast.LENGTH_SHORT).show();
                    break;
                }
            }
        });

        // -----------AQUI EMPIEZA LOS METODOS DE TEXTCHANGE--------
        //ESTE METODO CALCULA AUTOMATICAMENTE LAS CANTIDADES DE ACUERDO A
        //LO QUE EL USUARIO INGRESE EN LOS TEXTEDIT.

       centavos.addTextChangedListener(new TextWatcher() {
           @Override
           public void beforeTextChanged(CharSequence s, int start, int count, int after) {

           }
           @Override
           public void onTextChanged(CharSequence s, int start, int before, int count) {
               try{

                   centavo = Float.parseFloat(s.toString())*0.01f;

                   txtCentavos.setText("$ "+f.format(centavo));
                   sumaT=sumaT+centavo;
                   txtTotal.setText(f.format(sumaT));
                   Sumando();
                   SumaTotal();

               }catch (NumberFormatException e){
                   //Toast.makeText(MainActivity.this, "Todas las denominaciones 😯", Toast.LENGTH_SHORT).show();
                   txtCentavos.setText("");
                   centavo = 0f;
                   Sumando();
                   SumaTotal();

               }

           }
           @Override
           public void afterTextChanged(Editable s) {

           }
       });
        //Dolares
        dolares.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{

                    dolar= Float.parseFloat(s.toString())*1f;

                    txtDolar.setText("$ "+f.format(dolar));
                    sumaT=sumaT+dolar;
                    txtTotal.setText(f.format(sumaT));
                    Sumando();
                    SumaTotal();

                }catch (NumberFormatException e){
                    //Toast.makeText(MainActivity.this, "Todas las denominaciones 😯", Toast.LENGTH_SHORT).show();
                    txtDolar.setText("");
                    dolar = 0f;
                    Sumando();
                    SumaTotal();

                }

            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //5 Dolares
        cincoDolares.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{

                    cinco= Float.parseFloat(s.toString())*5f;

                    txtcincoDolares.setText("$ "+f.format(cinco));
                    sumaT=sumaT+cinco;
                    txtTotal.setText(f.format(sumaT));
                    Sumando();
                    SumaTotal();

                }catch (NumberFormatException e){
                    //Toast.makeText(MainActivity.this, "Todas las denominaciones 😯", Toast.LENGTH_SHORT).show();
                    txtcincoDolares.setText("");
                    cinco = 0f;
                    Sumando();
                    SumaTotal();

                }

            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //10 Dolares
        diezDolares.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{

                    diez= Float.parseFloat(s.toString())*10f;

                    txtdiezDolares.setText("$ "+f.format(diez));
                    sumaT=sumaT+diez;
                    txtTotal.setText(f.format(sumaT));
                    Sumando();
                    SumaTotal();

                }catch (NumberFormatException e){
                    //Toast.makeText(MainActivity.this, "Todas las denominaciones 😯", Toast.LENGTH_SHORT).show();
                    txtdiezDolares.setText("");
                    diez = 0f;
                    Sumando();
                    SumaTotal();

                }

            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //20 Dolares
        veinteDolares.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{

                    veinte= Float.parseFloat(s.toString())*20f;

                    txtveinteDolares.setText("$ "+f.format(veinte));
                    sumaT=sumaT+veinte;
                    txtTotal.setText(f.format(sumaT));
                    Sumando();
                    SumaTotal();

                }catch (NumberFormatException e){
                    //Toast.makeText(MainActivity.this, "Todas las denominaciones 😯", Toast.LENGTH_SHORT).show();
                    txtveinteDolares.setText("");
                    veinte = 0f;
                    Sumando();
                    SumaTotal();

                }

            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //50 Dolares
        cincuentaDolares.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{

                    cincuenta= Float.parseFloat(s.toString())*50f;

                    txtcincuentaDolares.setText("$ "+f.format(cincuenta));
                    sumaT=sumaT+cincuenta;
                    txtTotal.setText(f.format(sumaT));
                    Sumando();
                    SumaTotal();

                }catch (NumberFormatException e){
                    //Toast.makeText(MainActivity.this, "Todas las denominaciones 😯", Toast.LENGTH_SHORT).show();
                    txtcincuentaDolares.setText("");
                    cincuenta = 0f;
                    Sumando();
                    SumaTotal();

                }

            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //100 Dolares
        cienDolares.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{

                    cien= Float.parseFloat(s.toString())*100f;

                    txtcienDolares.setText("$ "+f.format(cien));
                    sumaT=sumaT+cien;
                    txtTotal.setText(f.format(sumaT));
                    Sumando();
                    SumaTotal();

                }catch (NumberFormatException e){
                    //Toast.makeText(MainActivity.this, "Todas las denominaciones 😯", Toast.LENGTH_SHORT).show();
                    txtcienDolares.setText("");
                    cien = 0f;
                    Sumando();
                    SumaTotal();

                }

            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //retiros
        retiros.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{

                    //Float r= Float.parseFloat(s.toString());
                    //retiro =Float.parseFloat(f.format(r));
                        retiro = Float.parseFloat(s.toString());

                    sumaTF=retiro;
                    txtTotalCinta.setText(f.format(sumaTF));
                    Sumando();
                    SumaTotal();

                }catch (NumberFormatException e){
                    //Toast.makeText(MainActivity.this, "Todas las denominaciones 😯", Toast.LENGTH_SHORT).show();
                    //txtcincoDolares.setText("");
                    sumaTF = 0f;
                    SumaTotal();

                }

            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });


    }
    //Este metodo es el que se encarga de sumar el total de los billetes
    DecimalFormat f=new DecimalFormat("###,##0.00");
    public void Sumando(){
        sumaT = centavo+dolar+cinco+diez+veinte+cincuenta+cien;
        txtTotal.setText("$ "+f.format(sumaT));
        // Float total=suma+Float.parseFloat(retiros.getText().toString());
        // txtTotalCinta.setText("$ "+f.format(total));
    }
    public  void SumaTotal(){
        Float s = sumaT+sumaTF;
        txtTotalCinta.setText(f.format(s));
    }
    public void adjustFontScale(Configuration configuration)
    {
        configuration.fontScale = (float) 1.0;
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        wm.getDefaultDisplay().getMetrics(metrics);
        metrics.scaledDensity = configuration.fontScale * metrics.density;
        getBaseContext().getResources().updateConfiguration(configuration, metrics);
    }

    //Metodo para ingresar a la otra pantalla
    public void abrirCalc(View view){
        Intent intent=new Intent(MainActivity.this,Calculadoras.class);
        startActivity(intent);
    }


    /* METODO QUE SIRVE PARA COMPROBAR QUE NO HAYAN CAMPOS VACIOS
    Y DE HABERLOS SE LES ASIGNA UN CERO AL CAMPO PARA REALIZAR LA OPERACION CORRESPONDIENTE */
    public void validacion(){

        if (centavos.getText().toString().isEmpty()) {
            centavos.setText("0");
        }
        if  (dolares.getText().toString().isEmpty()){
            dolares.setText("0");
        }
        if(cincoDolares.getText().toString().isEmpty()){
            cincoDolares.setText("0");
        }
        if (diezDolares.getText().toString().isEmpty()){
            diezDolares.setText("0");
        }
        if(veinteDolares.getText().toString().isEmpty()){
            veinteDolares.setText("0");
        }
        if (cincuentaDolares.getText().toString().isEmpty()){
            cincuentaDolares.setText("0");
        }
        if (cienDolares.getText().toString().isEmpty()){
            cienDolares.setText("0");
        }
        else {
            if (clicCalcular==1)
                Toast.makeText(MainActivity.this, "Todas las denominaciones 😯", Toast.LENGTH_SHORT).show();
        }
        if (retiros.getText().toString().isEmpty()){
            retiros.setText("0");
        }



    }
    /* METODO QUE REALIZA LA OPERACION DE MULTIPLICAR LOS VALORES INGRESADOS Y
          MOSTRAR LOS RESULTADOS AL USUARIO*/
    public void Operando(){
        //Formato de la moneda: miles separados por coma, decimales con punto
        DecimalFormat f=new DecimalFormat("###,##0.00");
        centavo= Float.parseFloat(centavos.getText().toString())*0.01f;
        txtCentavos.setText("$ "+f.format(centavo));

        dolar= Float.parseFloat(dolares.getText().toString())*1f;
        txtDolar.setText("$ "+f.format(dolar));

        cinco=Float.parseFloat(cincoDolares.getText().toString())*5;
        txtcincoDolares.setText("$ "+f.format(cinco));

        diez=Float.parseFloat(diezDolares.getText().toString())*10;
        txtdiezDolares.setText("$ "+f.format(diez));

        veinte=Float.parseFloat(veinteDolares.getText().toString())*20;
        txtveinteDolares.setText("$ "+f.format(veinte));

        cincuenta=Float.parseFloat(cincuentaDolares.getText().toString())*50;
        txtcincuentaDolares.setText("$ "+f.format(cincuenta));

        cien=Float.parseFloat(cienDolares.getText().toString())*100;
        txtcienDolares.setText("$ "+f.format(cien));

        Float suma=centavo+dolar+cinco+diez+veinte+cincuenta+cien;
        txtTotal.setText("$ "+f.format(suma));
        Float total=suma+Float.parseFloat(retiros.getText().toString());
        txtTotalCinta.setText("$ "+f.format(total));
    }

    // METODO QUE SIRVE PARA BORRAR LA INFORMACION DE LOS CAMPOS

    public void Borrar(){
        centavos.setText("");
        dolares.setText("");
        cincoDolares.setText("");
        diezDolares.setText("");
        veinteDolares.setText("");
        cincuentaDolares.setText("");
        cienDolares.setText("");
        retiros.setText("");

        txtCentavos.setText("");
        txtDolar.setText("");
        txtcincoDolares.setText("");
        txtdiezDolares.setText("");
        txtveinteDolares.setText("");
        txtcincuentaDolares.setText("");
        txtcienDolares.setText("");
        txtTotal.setText("");
        txtTotalCinta.setText("");
        Toast.makeText(this, "Datos Borrados con exito 🚮", Toast.LENGTH_SHORT).show();
    }






    @Override
    public void onClick(View view) {

    }






}